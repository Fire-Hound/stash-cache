from collections import namedtuple

Signature = namedtuple("Signature", ["func_name", "args", "kwargs", "func"])