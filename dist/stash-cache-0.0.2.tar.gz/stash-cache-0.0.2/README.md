# Stash [![Stash-cache](https://github.com/Fire-Hound/stash-cache/actions/workflows/main.yml/badge.svg)](https://github.com/Fire-Hound/stash-cache/actions/workflows/main.yml)

![Stash Banner](./assets/Stash-logo.png)

Stash helps you to safely persist your function cache.

Stash gives you your functions the superpower of remembrance. Stash speeds up your functions by stashing their output and only running them when the argument or the body of the function changes.
